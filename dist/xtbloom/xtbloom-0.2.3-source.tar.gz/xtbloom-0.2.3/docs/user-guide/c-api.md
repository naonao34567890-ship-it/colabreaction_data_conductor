# C and C++ API

xTBloom is implemented in C++17, but its only public native interface is the C
header `xtbloom/xtbloom.h`. The header is C11-compatible and has `extern "C"`
guards, so C and C++ consumers share the same ABI and semantics.

## Install and link

Read the [installation prerequisites](index.md#prerequisites) first. The command
below keeps the default `AUTO` CUDA selection and disables repository tests;
leave tests enabled only when Python 3.11 or newer and the development
prerequisites are available.

```console
cmake -S . -B build/release -G Ninja \
  -DXTBLOOM_BUILD_TESTS=OFF \
  -DBUILD_SHARED_LIBS=ON \
  -DCMAKE_BUILD_TYPE=Release
cmake --build build/release --parallel
cmake --install build/release --prefix "$PWD/build/install"
```

CUDA selection normally defaults to `AUTO`. For an explicitly verified CUDA
build, use a separate directory, set `XTBLOOM_ENABLE_CUDA=ON` so a missing
compiler is an error, and select the deployment GPU architecture:

```console
cmake -S . -B build/cuda -G Ninja \
  -DXTBLOOM_ENABLE_CUDA=ON \
  -DCMAKE_CUDA_ARCHITECTURES=89 \
  -DXTBLOOM_BUILD_TESTS=OFF \
  -DBUILD_SHARED_LIBS=ON \
  -DCMAKE_BUILD_TYPE=Release
cmake --build build/cuda --parallel
cmake --install build/cuda --prefix "$PWD/build/install-cuda"
```

Replace `89` with the target compute capability. Set
`context_options.backend = XTBLOOM_BACKEND_CUDA` to require GPU execution;
`XTBLOOM_BACKEND_AUTO` may fall back to CPU. The complete example below uses
CPU by default so it also runs with the CPU-only install; change its one backend
line to `XTBLOOM_BACKEND_CUDA` to verify the CUDA build explicitly.

`xtbloom_compute_options_init` defaults `compute_options.model` to
`XTBLOOM_MODEL_GFN2_XTB`. Set it explicitly to `XTBLOOM_MODEL_GFN1_XTB` for
GFN1 execution on CPU or CUDA; the library never substitutes GFN2. GFN1
publishes energy, forces, charges, and point-charge forces, and
accepts caller-supplied `b` and `A` fields for the `b + A*q` response. It does
not support electric-field attachments or the molecular-dipole outlet.

A consumer CMake project needs only the exported target:

```cmake
cmake_minimum_required(VERSION 3.24)
project(xtbloom_example LANGUAGES C CXX)

find_package(xtbloom CONFIG REQUIRED)
add_executable(xtbloom_example main.c)
target_link_libraries(xtbloom_example PRIVATE xtbloom::xtbloom)
target_compile_features(xtbloom_example PRIVATE c_std_11)
```

Configure it with the selected install prefix. Use `build/install-cuda` instead
when following the CUDA build above:

```console
cmake -S example -B example/build -G Ninja \
  -DCMAKE_PREFIX_PATH="$PWD/build/install"
cmake --build example/build
example/build/xtbloom_example
```

## Complete energy and force example

This example submits one H2 molecule using host buffers. A CUDA context accepts
the same descriptors and stages them internally; select it explicitly as
described above when verifying GPU execution.

```c
#include <math.h>
#include <stdint.h>
#include <stdio.h>

#include <xtbloom/xtbloom.h>

static xtbloom_const_buffer_t input_buffer(const void *data, size_t size) {
  xtbloom_const_buffer_t buffer = {data, size, XTBLOOM_MEMORY_HOST, 0};
  return buffer;
}

static xtbloom_buffer_t output_buffer(void *data, size_t size) {
  xtbloom_buffer_t buffer = {data, size, XTBLOOM_MEMORY_HOST, 0};
  return buffer;
}

int main(void) {
  const int64_t atom_offsets[] = {0, 2};
  const int32_t atomic_numbers[] = {1, 1};
  const double positions[] = {-0.70, 0.0, 0.0, 0.70, 0.0, 0.0};
  const double molecular_charges[] = {0.0};
  const int32_t unpaired_electrons[] = {0};

  xtbloom_context_options_t context_options;
  xtbloom_batch_t batch;
  xtbloom_compute_options_t compute_options;
  xtbloom_batch_result_t result;
  if (xtbloom_context_options_init(&context_options, sizeof(context_options)) !=
          XTBLOOM_STATUS_SUCCESS ||
      xtbloom_batch_init(&batch, sizeof(batch)) != XTBLOOM_STATUS_SUCCESS ||
      xtbloom_compute_options_init(&compute_options, sizeof(compute_options)) !=
          XTBLOOM_STATUS_SUCCESS ||
      xtbloom_batch_result_init(&result, sizeof(result)) != XTBLOOM_STATUS_SUCCESS) {
    fprintf(stderr, "descriptor initialization failed: %s\n",
            xtbloom_get_last_error());
    return 1;
  }

  context_options.backend = XTBLOOM_BACKEND_CPU;

  batch.batch_size = 1;
  batch.total_atoms = 2;
  batch.atom_offsets = input_buffer(atom_offsets, sizeof(atom_offsets));
  batch.atomic_numbers = input_buffer(atomic_numbers, sizeof(atomic_numbers));
  batch.positions = input_buffer(positions, sizeof(positions));
  batch.molecular_charges =
      input_buffer(molecular_charges, sizeof(molecular_charges));
  batch.unpaired_electrons =
      input_buffer(unpaired_electrons, sizeof(unpaired_electrons));

  compute_options.flags = XTBLOOM_COMPUTE_ENERGY | XTBLOOM_COMPUTE_FORCES |
                          XTBLOOM_COMPUTE_ATOMIC_CHARGES;
  /* The initializer defaults to GFN2. Select GFN1 explicitly when desired:
   * compute_options.model = XTBLOOM_MODEL_GFN1_XTB; */

  double energy = NAN;
  double forces[6];
  double charges[2];
  int32_t iterations = -1;
  uint8_t converged = 0;
  xtbloom_status_t system_status = XTBLOOM_STATUS_INTERNAL_ERROR;
  result.energies = output_buffer(&energy, sizeof(energy));
  result.forces = output_buffer(forces, sizeof(forces));
  result.atomic_charges = output_buffer(charges, sizeof(charges));
  result.scc_iterations = output_buffer(&iterations, sizeof(iterations));
  result.scc_converged = output_buffer(&converged, sizeof(converged));
  result.per_system_status =
      output_buffer(&system_status, sizeof(system_status));

  xtbloom_context_t *context = NULL;
  xtbloom_status_t status = xtbloom_context_create(&context_options, &context);
  if (status != XTBLOOM_STATUS_SUCCESS) {
    fprintf(stderr, "context creation failed: %s\n", xtbloom_get_last_error());
    return 2;
  }

  status = xtbloom_compute(context, &batch, &compute_options, &result);
  if (status != XTBLOOM_STATUS_SUCCESS) {
    fprintf(stderr, "compute failed: %s\n", xtbloom_get_last_error());
    xtbloom_context_destroy(context);
    return 3;
  }
  xtbloom_context_destroy(context);
  if (system_status != XTBLOOM_STATUS_SUCCESS) {
    fprintf(stderr, "system failed: %s\n", xtbloom_status_string(system_status));
    return 4;
  }

  printf("energy = %.16g Hartree, SCC iterations = %d\n", energy, iterations);
  printf("force on atom 0 = (%.16g, %.16g, %.16g) Hartree/bohr\n",
         forces[0], forces[1], forces[2]);
  return converged == 1 && isfinite(energy) ? 0 : 5;
}
```

## Descriptor rules

Every extensible structure begins with `struct_size` and `api_version`. Always
call the matching initializer with the caller's `sizeof(struct)` before setting
fields. This lets a newer library recognize a shorter compatible structure and
prevents accidental reads beyond the supplied ABI prefix.

All buffer views are caller-owned borrowed memory. xTBloom never takes
ownership, reallocates a caller buffer, or retains request pointers after the
synchronous call returns. Buffer `size_bytes`, memory-space tags, offsets, and
all extents are validated before execution.

Required batch topology uses flat arrays:

- `atom_offsets` has `batch_size + 1` signed 64-bit values;
- `atomic_numbers` has `total_atoms` signed 32-bit values;
- `positions` has `3 * total_atoms` binary64 values;
- molecular charges and unpaired-electron counts have one value per system;
- optional point-charge and charge-response arrays have their own 64-bit
  offsets and total extents.

See the public header for every optional field and its exact element type.

## Native cell descriptors (ABI-v4)

The ABI-v4 `xtbloom_batch_t` suffix appends `cell_matrices` and
`periodic_axes`. Both are caller-owned borrowed buffers with one entry per
system: each cell is nine row-major binary64 values in bohr whose rows are the
direct vectors `a`, `b`, and `c`; each periodicity entry is a fixed-width
`int32_t` mask. This release accepts `XTBLOOM_PERIODIC_AXES_NONE` for a
molecular item and reserves the X/Y/Z bits, with `XTBLOOM_PERIODIC_AXES_XYZ`
describing three-dimensional periodicity. One- and two-dimensional masks are
reserved but not supported.

The two buffers must be supplied together. A `NONE` item uses an all-zero cell;
an `XYZ` item requires a finite, right-handed, nonsingular cell. V1/V2/V3
callers and V4 batches containing only `NONE` items keep molecular behavior.
CPU GFN2 accepts complete `XYZ` requests for energy, forces, and atomic
charges. A CPU GFN2 request may additionally set
`XTBLOOM_COMPUTE_STRAIN_DERIVATIVES` and provide the ABI-v3 result suffix;
the nine row-major values are the fixed-alpha derivative `Xi = dE/dε` in
Hartree for the affine direct-cell deformation documented in
`docs/theory/periodic-gfn2.md`. CUDA GFN2 `XYZ` requests currently use the same
validated CPU periodic evaluator through an asynchronous host bridge; they are
not yet CUDA-native Ewald/multipole execution. GFN1 `XYZ` remains explicitly
refused until its periodic physics is connected. This descriptor is not the
caller-supplied periodic `b + A*q` embedding operator and does not make
solvation periodic.

## External interaction attachments (ABI-v3)

The ABI-v3 `xtbloom_batch_t` suffix carries a generic, versioned attachment
slot so future external interactions do not renumber or regrow the batch
layout for each new feature. When present:

- `total_interactions` counts `xtbloom_interaction_t` entries in
  `interaction_descriptors`;
- each descriptor attaches one caller-owned payload block inside the
  `interaction_payload` byte buffer to one batch item (`system_index`);
- `interaction_descriptors` and `interaction_payload` may independently use
  host or CUDA-device memory, like every other buffer.

Every payload block starts with an `int32_t block_version` so the byte layout
of one tag can evolve independently; the header must fit in the payload view
and be aligned to an `int32_t`. The released electric-field block
(`XTBLOOM_INTERACTION_ELECTRIC_FIELD`, block version 1) is 32 bytes:
`int32_t version`, a zero `int32_t reserved`, and three finite binary64 field
components in Hartree per elementary charge per bohr. Its payload offset is
8-byte aligned.

The tag set is reserved for the xtb/tblite/dxtb interaction family: uniform
electric field and field gradient, multipole point charges, atomic-potential
grids, ALPB/GBSA/GB/GBE/ddX solvation, D3/D4 dispersion variants, and
halogen-bond corrections. The CPU and CUDA backends execute the uniform
electric field (`XTBLOOM_INTERACTION_ELECTRIC_FIELD`); every other reserved tag
is refused with `XTBLOOM_STATUS_NOT_IMPLEMENTED` before any caller output is
touched, so a reserved interaction can never silently contribute to a result.
Unknown or `XTBLOOM_INTERACTION_NONE` tags,
duplicate `(system_index, type)` attachments, descriptor flag bits, and payload
blocks that are undersized, oversized, misaligned, or outside the payload view
are `XTBLOOM_STATUS_INVALID_ARGUMENT`.

On both backends the uniform electric field contributes a per-atom scalar
potential `vat_i = -E . r_i` and a per-atom dipolar potential `vdp = -E` to the
charge channel of the SCC Hamiltonian on every iteration (matching the pinned
tblite `field.f90` potential), an energy term `-sum_i q_i (E . r_i)
- sum_i E . d_i` in the SCC trace, and the explicit Hellmann-Feynman force
`+q_i E` on atom `i`. The stationary response of the converged charges and
atomic dipoles is already carried by the field potentials. The pinned tblite
0.7.0 analytic result applies a `+E`-per-atom force (equivalently a `-E`
gradient contribution) and is nonvariational for partial charges, so xTBloom
validates field forces against central differences of its reported energy
instead of treating that result as an oracle. Because the
field participates in every SCC iteration it is part of
the strict warm-start identity: a `WARM` call whose field differs from the
latest fully converged compatible call is rejected like any other changed
compute policy.

The ABI-v2 `xtbloom_batch_result_t` suffix adds the dipole outlet:
`dipole_moments` holds `batch_size * 3` binary64 values in atomic units. It is
reported when `XTBLOOM_COMPUTE_DIPOLE_MOMENTS` is set in `compute_options.flags`.
Both backends publish the molecular dipole `sum_i (r_i * q_i + d_i)` over the
converged charge-channel SCC multipoles and set `XTBLOOM_RESULT_DIPOLE_MOMENTS`.
`quadrupole_moments`, `wiberg_orders`, and
`spin_populations` are ABI-reserved outlets whose shape contract is not
published: supplying bytes there is refused with
`XTBLOOM_STATUS_NOT_SUPPORTED`.

Compute-flag bits 16-31 are reserved and must be zero on input. Result flags
are outputs; xTBloom keeps their reserved bits 16-31 zero on successful return.

## Outputs and failures

The three diagnostic arrays `scc_iterations`, `scc_converged`, and
`per_system_status` are required for every nonempty request. Floating-point
output buffers are required only for properties selected in
`compute_options.flags`.

A successful function return means the batch diagnostics were published; it
does not mean every system converged. Inspect each `per_system_status` entry.
Failed system slices contain quiet NaNs, while successful peer slices remain
valid.

Request validation completes before execution or caller-output publication.
Failures before publication leave output buffers and result flags unchanged.
After CUDA publication begins, a catastrophic device/runtime failure may have
modified outputs and returns `XTBLOOM_STATUS_INTERNAL_ERROR` with a thread-local
diagnostic from `xtbloom_get_last_error()`.

## CUDA descriptors and streams

Set `context_options.backend = XTBLOOM_BACKEND_CUDA` and optionally choose
`device_id` or a native `cudaStream_t` cast to `void *`. Each buffer independently
uses `XTBLOOM_MEMORY_HOST` or `XTBLOOM_MEMORY_CUDA_DEVICE`, so mixed requests are
valid. Pointer ownership and the selected device are validated.

`xtbloom_compute` is synchronous with respect to the caller even when a custom
stream is supplied. Active CUDA stream capture is rejected. xTBloom attempts to
restore the caller's current device on every exit.

For native asynchronous CUDA submission, create a reusable
`xtbloom_request_t` and call either `xtbloom_compute_enqueue` or the
fixed-topology `xtbloom_plan_compute_enqueue`. A successful enqueue copies the
descriptor images and every host input needed after return; CUDA inputs and all
outputs must remain alive until the request is `COMPLETE`. Query is
nonblocking, while wait and request destruction settle that exact submission.
Completion flags are returned by `xtbloom_request_info_t.result_flags`; the
copied `xtbloom_batch_result_t.flags` field is deliberately not modified.
Context enqueue may do bounded setup work for a first or changed topology,
whereas a prepared same-topology path leaves inference and result publication
ordered only on the context stream. CPU enqueue is a capability probe that
returns `NOT_SUPPORTED` before inspecting descriptors. ABI-v2 strict `WARM` is
available on both CUDA enqueue entry points and obeys the same one-checkpoint
contract as synchronous compute: it never falls back to `FRESH`, consumes the
checkpoint in stream order, and publishes a replacement only after the complete
batch succeeds. A deferred topology or execution failure invalidates the
consumed checkpoint while preserving caller outputs under the normal
transactional publication rules.

## xTBloom-owned result arenas and DLPack export

`xtbloom_result_owner_t` is an additive, ref-counted result-allocation owner:
one contiguous host or CUDA-device arena that xTBloom itself allocates, fills
through a normal compute call, and can hand to an importing framework with the
DLPack producer protocol without copying data.

- `xtbloom_result_owner_create` allocates one arena with an initial reference
  (options: memory space, device id, byte size). `xtbloom_result_owner_buffer`
  exposes the arena as a caller-owned `xtbloom_buffer_t` so output slices can
  be bound and computed into.
- `xtbloom_result_owner_retain` / `xtbloom_result_owner_release` manage the
  reference count; the allocation is freed exactly once when the last
  reference drops. `release(NULL)` is a no-op and every release must
  correspond to exactly one prior create or retain.
- `xtbloom_result_owner_export_dltensor` wraps one compact C-contiguous arena
  slice as a heap-allocated `DLManagedTensor` (legacy, `version == 0`) or
  `DLManagedTensorVersioned` (DLPack 1.0, `version != 0`). The managed tensor
  carries a native exact-once deleter, so importing frameworks can release it
  from their own code after the producing context and Python wrapper are gone;
  no hidden host polling or extra device-wide synchronization is required
  because public compute is synchronous. On any failure `*out_managed` is set
  to NULL and no arena reference is taken.
- The Python package mirrors these functions in `xtbloom.library` and exposes
  the producer through `ArrayBatch.compute(result_memory="cuda")`; see the
  Python guide for the user-facing contract.

## Reuse and warm starts

Keep a context alive across calls to retain worker pools, topology plans, and
backend workspaces. ABI-v2 `XTBLOOM_SCC_START_WARM` additionally consumes the
checkpoint from the most recent fully converged compatible batch. It is strict:
a first call, topology/policy change, or missing compatible checkpoint is an
invalid argument and never falls back to `FRESH`. An accepted `FRESH` attempt
consumes the preceding compatible checkpoint before execution. If that attempt
later fails—including a stream-ordered CUDA error discovered after enqueue—the
older checkpoint is not reused, and the next strict `WARM` call rejects.

For otherwise identical inputs at the same geometry, a `WARM` call restarts SCC
from the checkpoint electronic state and reconverges, so its reported energy
agrees with the energy associated with the consumed checkpoint within the SCC
energy tolerance rather than bit-for-bit: the exact reconverged point can
differ in the final ulp across hosts and BLAS kernels. A compatible checkpoint
can come from either `FRESH` or `WARM`. Each fully converged batch call
publishes the checkpoint consumed by the next compatible `WARM` request, so
consecutive `WARM` calls are stateful and do not carry a bitwise-identical
result guarantee.

Geometry may change while topology and compute policy remain identical. CPU
restarts its mixing window from the converged electronic state; CUDA preserves
only epoch-compatible mixer history. See
[architecture](../developer-guide/architecture.md) for the full identity and
cache contract.

ABI-v3 callers may select the modified-Broyden history depth (`1..64`) and
damping (`0 < damping <= 1`); history 8 and damping 0.4 preserve the earlier
behavior. `XTBLOOM_DETERMINISM_REPRODUCIBLE` requests bitwise replay only when
the complete execution environment and start-mode sequence are unchanged. It
includes the CPU ISA selected when the context was created and is not a
CPU/CUDA, cross-ISA, or cross-provider/toolkit/architecture equivalence
promise. All three mixer fields and the determinism tag are part of fixed-plan,
cache/Graph, and strict-WARM identity.
