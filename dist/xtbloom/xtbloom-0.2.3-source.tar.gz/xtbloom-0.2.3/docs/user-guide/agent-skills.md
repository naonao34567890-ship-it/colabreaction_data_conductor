# Skills for AI agents

User-facing skills live in [`skills/`](../../skills). Contributor workflows
remain separate under [`.agents/skills/`](../../.agents/skills).

These user skills are intentionally task-scoped rather than one monolithic
skill. Each `SKILL.md` is a small router that loads only the references needed
for Python inference, adapters, ML arrays, the C API, QM/MM, or installation.
For standalone Python tasks, they prefer PEP 723 metadata and execute it with
`uv run --script`. Framework integrations add only the adapter or ML framework
the user actually selected. Native C/C++ workflows continue to use the
installed CMake package and compiler toolchain.

## Choose a skill

| Skill | Use it for |
| --- | --- |
| `xtbloom-install-and-diagnose` | Use the PyPI package by default or a source checkout when required, select CPU or CUDA deliberately, inspect native-library discovery, and prove which backend actually executes. |
| `xtbloom-run-python-inference` | Write single-system or native ragged-batch Python calculations with correct units, spin, warm-start, and per-system failure handling. |
| `xtbloom-integrate-ase-dpdata` | Attach xTBloom to ASE or dpdata for energies, forces, dataset labeling, or adapter-level relaxation. |
| `xtbloom-use-zero-copy-ml` | Connect NumPy, CuPy, JAX, or PyTorch arrays through Array API and DLPack, including caller-owned outputs and the positions-only PyTorch gradient. |
| `xtbloom-integrate-c-api` | Build an installed C or C++ consumer with versioned descriptors, caller-owned buffers, ragged batches, CUDA memory tags, and result diagnostics. |
| `xtbloom-couple-qmmm` | Add explicit point charges or a caller-supplied `b + A q` charge-response operator and account for the force terms xTBloom intentionally excludes. |

## Load a skill

Ask the agent to load the matching `SKILL.md`, for example:

```text
Read skills/xtbloom-run-python-inference/SKILL.md and use that skill to write
a CUDA ragged-batch calculation for these XYZ structures while preserving
per-system failures.
```

For a client that installs skills from GitHub, use the repository and skill
path directly:

```text
Repository: jinzhezenggroup/xtbloom
Path: skills/xtbloom-run-python-inference
```

Each skill directory is self-contained and uses its `references/` directory for
progressive disclosure. Clients may ignore `agents/openai.yaml` when they use
only the portable `SKILL.md` convention.
