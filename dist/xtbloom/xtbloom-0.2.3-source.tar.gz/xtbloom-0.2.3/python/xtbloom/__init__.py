"""xTBloom: batched GFN-xTB energy and analytic-force inference.

The Python package wraps the public xTBloom C ABI through :mod:`ctypes`,
marshals numpy arrays between Python and the C descriptors, and exposes a
tblite-like high-level interface (:class:`xtbloom.interface.Calculator`),
the native ragged-batch model (:class:`xtbloom.interface.BatchCalculator`),
plus optional ASE (:mod:`xtbloom.ase`) and dpdata (:mod:`xtbloom.dpdata`)
integrations.

Atomic units everywhere: bohr, Hartree, Hartree/bohr, elementary charge.
"""

from importlib.metadata import version as _distribution_version

from ._dlpack import DLPackResultBuffer
from .exceptions import (
    XTBloomError,
    XTBloomNotSupportedError,
    XTBloomRuntimeError,
    XTBloomValueError,
)
from .interface import (
    ArrayBatch,
    ArrayBatchResult,
    BatchCalculator,
    BatchResult,
    Calculator,
    ChargeResponse,
    Context,
    PointCharge,
    Result,
    Structure,
    compute_arrays,
    numbers_to_symbols,
    symbols_to_numbers,
)
from .optimize import OptimizationResult, optimize, optimize_batch
from .torch import xtbloom_torch
from .vibrations import VibrationalResult, analyze_vibrations, vibrations

# The build backend records exact release tags or revision-aware development
# versions in the installed distribution metadata. Reading it here avoids a
# second generated or hand-maintained Python version source; the embedded
# native library deliberately keeps the nearest release-tag version instead.
__version__ = _distribution_version("xtbloom")
del _distribution_version

__all__ = [
    "ArrayBatch",
    "ArrayBatchResult",
    "BatchCalculator",
    "BatchResult",
    "Calculator",
    "ChargeResponse",
    "Context",
    "DLPackResultBuffer",
    "OptimizationResult",
    "PointCharge",
    "Result",
    "Structure",
    "VibrationalResult",
    "XTBloomError",
    "XTBloomNotSupportedError",
    "XTBloomRuntimeError",
    "XTBloomValueError",
    "__version__",
    "analyze_vibrations",
    "compute_arrays",
    "numbers_to_symbols",
    "optimize",
    "optimize_batch",
    "symbols_to_numbers",
    "vibrations",
    "xtbloom_torch",
]
