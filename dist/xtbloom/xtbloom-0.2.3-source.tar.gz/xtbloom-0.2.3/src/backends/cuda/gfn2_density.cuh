#ifndef XTBLOOM_BACKENDS_CUDA_GFN2_DENSITY_CUH
// xtbloom's CUDA/MKL additional permission is in CUDA_MKL_LINKING_EXCEPTION.

#define XTBLOOM_BACKENDS_CUDA_GFN2_DENSITY_CUH

#include <cuda_runtime_api.h>

#include <cmath>
#include <cstdint>
#include <type_traits>

#include "backends/common/gfn2_plan_schema.hpp"

namespace xtbloom::detail::cuda {

/* Topology-fixed upper bound for pair tiles assigned to one system/channel. */
inline constexpr std::int64_t kGfn2DensityContractBlockBudget = 512;
/* Shared by density launches and the setup-time pair-tile selector. */
inline constexpr int kGfn2DensityThreadsPerBlock = 256;

/*
 * Packed lower-triangle indexing shared by independent AO-pair kernels. The
 * inverse uses a floating estimate followed by exact integer correction so
 * every valid packed index maps to one deterministic matrix pair.
 */
struct Gfn2PackedMatrixPair {
  std::int64_t row;
  std::int64_t column;
};

__host__ __device__ inline std::int64_t gfn2_triangle_inclusive(std::int64_t value) {
  return (value & 1LL) == 0LL ? (value / 2LL) * (value + 1LL) : value * ((value + 1LL) / 2LL);
}

__device__ inline Gfn2PackedMatrixPair gfn2_packed_matrix_pair(std::int64_t packed) {
  std::int64_t row =
      static_cast<std::int64_t>(0.5 * (::sqrt(1.0 + 8.0 * static_cast<double>(packed)) - 1.0));
  while (row > 0 && gfn2_triangle_inclusive(row) > packed) {
    --row;
  }
  while (gfn2_triangle_inclusive(row + 1) <= packed) {
    ++row;
  }
  const std::int64_t previous = gfn2_triangle_inclusive(row);
  return {row, packed - previous};
}

/*
 * Host-visible contract for the kernel node captured into the SCC Graph.
 * total_spin_channels distinguishes an all-restricted batch (one launched
 * channel) from a batch containing any unrestricted system (two launched
 * channels) without reading device metadata or the iteration active mask.
 */
struct Gfn2DensityContractLaunchShape {
  std::uint32_t systems = 0u;
  std::uint32_t channels = 0u;
  std::uint32_t tiles = 0u;
};

[[nodiscard]] bool make_gfn2_density_contract_launch_shape(
    std::int64_t batch_size, std::int64_t total_spin_channels, std::int64_t tiles_per_channel,
    Gfn2DensityContractLaunchShape& shape) noexcept;

/*
 * Select the Graph-stable pair-tile count from host topology. The selector
 * targets at most kGfn2DensityContractBlockBudget launched contraction CTAs
 * when capacity permits, while a grid-stride loop covers work beyond that target.
 * The output is changed only on success.
 */
[[nodiscard]] bool select_gfn2_density_contraction_tiles(const std::int64_t* orbital_offsets,
                                                         std::int64_t orbital_offset_count,
                                                         const std::int32_t* spin_channels,
                                                         std::int64_t spin_channel_count,
                                                         std::int64_t batch_size,
                                                         std::int64_t& tiles) noexcept;

/* Per-system failure code; the batch diagnostic is canonicalized by system index. */
enum class Gfn2DensityDeviceError : std::uint32_t {
  kSuccess = 0u,
  kInvalidActiveMask = 1u,
  kInvalidOffsets = 2u,
  kNonfiniteCoefficient = 3u,
  kNonfiniteEigenvalue = 4u,
  kInvalidOccupation = 5u,
  kNonfiniteWeightArithmetic = 6u,
  kNonfiniteBandEnergy = 7u,
  kNonfiniteDensityArithmetic = 8u,
  kNonfiniteWeightedDensityArithmetic = 9u,
  kNonfiniteTrace = 10u,
  kInvalidSpinChannels = 11u,
};

/*
 * Restricted ragged AO topology. orbital_offsets partitions eigenvalue and
 * coefficient dimensions; matrix_offsets partitions complete dense row-major
 * nao*nao matrices. Every active member must have at least one orbital and
 * matrix_offsets[s+1]-matrix_offsets[s] == nao*nao.
 */
struct Gfn2DensityDeviceBatch {
  std::int64_t batch_size = 0;
  std::int64_t total_orbitals = 0;
  std::int64_t total_matrix_elements = 0;
  /*
   * Topology-fixed pair tiles assigned to each system/channel. Setup balances
   * useful ragged work against a bounded total CTA target so Graph replay does
   * not depend on the per-iteration active mask.
   */
  std::int64_t contraction_tiles_per_channel = 0;
  std::int64_t orbital_offset_count = 0;
  std::int64_t matrix_offset_count = 0;
  std::uint64_t plan_token = 0u;
  const std::int64_t* orbital_offsets = nullptr;
  const std::int64_t* matrix_offsets = nullptr;
};

/*
 * Restricted eigenpairs and occupations. Coefficients are system-major dense
 * row-major [AO,orbital]. Eigenvalues own one row per system. Occupations use
 * #76 packing: system s starts at 2*orbital_offsets[s], followed by complete
 * alpha and beta rows. Inactive members are skipped before numerical inputs.
 */
struct Gfn2DensityDeviceInput {
  const double* coefficients = nullptr;
  std::int64_t coefficient_elements = 0;
  const double* eigenvalues = nullptr;
  std::int64_t eigenvalue_elements = 0;
  const double* occupations = nullptr;
  std::int64_t occupation_elements = 0;
  const std::uint8_t* active = nullptr;
  std::int64_t active_elements = 0;
  std::uint64_t plan_token = 0u;
};

/*
 * P and W are complete dense row-major matrices in matrix_offsets packing.
 * Scalar diagnostics are one value per system: band energy sum(f*epsilon),
 * total alpha+beta occupation, Tr(P), and Tr(W).
 */
struct Gfn2DensityDeviceResults {
  double* density = nullptr;
  std::int64_t density_elements = 0;
  double* energy_weighted_density = nullptr;
  std::int64_t weighted_density_elements = 0;
  double* band_energies = nullptr;
  std::int64_t band_energy_elements = 0;
  double* occupation_sums = nullptr;
  std::int64_t occupation_sum_elements = 0;
  double* density_traces = nullptr;
  std::int64_t density_trace_elements = 0;
  double* weighted_density_traces = nullptr;
  std::int64_t weighted_density_trace_elements = 0;
  std::uint64_t plan_token = 0u;

  /* Compact system-major/channel-major diagnostics in spin_channel_offsets. */
  double* channel_band_energies = nullptr;
  std::int64_t channel_band_energy_elements = 0;
  double* channel_occupation_sums = nullptr;
  std::int64_t channel_occupation_sum_elements = 0;
  double* channel_density_traces = nullptr;
  std::int64_t channel_density_trace_elements = 0;
  double* channel_weighted_density_traces = nullptr;
  std::int64_t channel_weighted_density_trace_elements = 0;
};

/* Caller-owned unpublished matrices, orbital weights, scalars, and sequence state. */
struct Gfn2DensityDeviceWorkspace {
  double* density_scratch = nullptr;
  std::int64_t density_elements = 0;
  double* weighted_density_scratch = nullptr;
  std::int64_t weighted_density_elements = 0;
  double* weights = nullptr;
  std::int64_t weight_elements = 0;
  double* energy_weights = nullptr;
  std::int64_t energy_weight_elements = 0;
  double* band_energy_scratch = nullptr;
  std::int64_t band_energy_elements = 0;
  double* occupation_sum_scratch = nullptr;
  std::int64_t occupation_sum_elements = 0;
  double* density_trace_scratch = nullptr;
  std::int64_t density_trace_elements = 0;
  double* weighted_density_trace_scratch = nullptr;
  std::int64_t weighted_density_trace_elements = 0;
  std::uint32_t* sequence_active = nullptr;
  std::int64_t sequence_active_elements = 0;
  std::uint64_t plan_token = 0u;

  /* Unpublished compact per-channel diagnostics for transactional publication. */
  double* channel_band_energy_scratch = nullptr;
  std::int64_t channel_band_energy_elements = 0;
  double* channel_occupation_sum_scratch = nullptr;
  std::int64_t channel_occupation_sum_elements = 0;
  double* channel_density_trace_scratch = nullptr;
  std::int64_t channel_density_trace_elements = 0;
  double* channel_weighted_density_trace_scratch = nullptr;
  std::int64_t channel_weighted_density_trace_elements = 0;
};

static_assert(std::is_trivially_copyable_v<Gfn2DensityDeviceBatch>);
static_assert(std::is_standard_layout_v<Gfn2DensityDeviceBatch>);
static_assert(std::is_trivially_copyable_v<Gfn2DensityDeviceInput>);
static_assert(std::is_standard_layout_v<Gfn2DensityDeviceInput>);
static_assert(std::is_trivially_copyable_v<Gfn2DensityDeviceResults>);
static_assert(std::is_standard_layout_v<Gfn2DensityDeviceResults>);
static_assert(std::is_trivially_copyable_v<Gfn2DensityDeviceWorkspace>);
static_assert(std::is_standard_layout_v<Gfn2DensityDeviceWorkspace>);

/* Clear per-system errors and the sticky canonical diagnostic. */
cudaError_t reset_gfn2_density_device_errors_cuda(std::int64_t batch_size,
                                                  std::uint32_t* system_errors,
                                                  std::uint32_t* device_error,
                                                  cudaStream_t stream = nullptr) noexcept;

/*
 * Assemble P=C(f_alpha+f_beta)C^T and
 * W=C((f_alpha+f_beta)*epsilon)C^T plus scalar diagnostics.
 *
 * Publication is atomic per system. Every product, accumulation, reduction,
 * and scalar is checked for finiteness before a separate publication kernel.
 * Matrix symmetry is exact because each lower-triangle contraction is written
 * to both dense directions. The launcher allocates nothing, synchronizes
 * nothing, uses only stream, and supports CUDA Graph capture/replay.
 */
cudaError_t evaluate_gfn2_restricted_density_cuda(const Gfn2DensityDeviceBatch& batch,
                                                  const Gfn2DensityDeviceInput& input,
                                                  const Gfn2DensityDeviceResults& results,
                                                  const Gfn2DensityDeviceWorkspace& workspace,
                                                  std::uint32_t* system_errors,
                                                  std::uint32_t* device_error,
                                                  cudaStream_t stream = nullptr) noexcept;

/*
 * Assemble density and energy-weighted density matrices for a mixed one- and
 * two-channel batch. Restricted systems retain the original arithmetic:
 * P=C(f_alpha+f_beta)C^T and one total P/W matrix. Unrestricted systems publish
 * separate alpha then beta matrices using system-major/spin-major packing.
 *
 * Per-channel diagnostics use spin_channel_offsets. Existing per-system
 * diagnostics are formed by the fixed channel-zero-then-channel-one sum. A
 * failure in either unrestricted channel suppresses every matrix and scalar
 * result for that peer. Unlike the legacy restricted entry point, this API
 * requires complete spin metadata and never interprets missing metadata as a
 * one-channel batch.
 */
cudaError_t evaluate_gfn2_spin_density_cuda(
    const Gfn2DensityDeviceBatch& batch, const Gfn2WavefunctionLayoutView& layout,
    const Gfn2DensityDeviceInput& input, const Gfn2DensityDeviceResults& results,
    const Gfn2DensityDeviceWorkspace& workspace, std::uint32_t* system_errors,
    std::uint32_t* device_error, cudaStream_t stream = nullptr) noexcept;

}  // namespace xtbloom::detail::cuda

#endif  // XTBLOOM_BACKENDS_CUDA_GFN2_DENSITY_CUH
